<?php

require_once 'abstract.php';

define("BLACKLIST_FILE_NAME", ".eclipse_plugin_tool_blacklist");

function shutdownHandler(){
	global $includeFilePath;
	if($includeFilePath!=null) {
		echo $includeFilePath;
	}
}

class Mage_Shell_EclipsePluginTool extends Mage_Shell_Abstract {

	const INCLUDE_FAST = 0;
	const INCLUDE_OMMIT = 1;

	protected $_includeMode = self::INCLUDE_FAST;

	protected function writeParent($writer, $class) {
		$parent = get_parent_class($class);
		if(!$parent)
			return;
		$writer->startElement("parent");
		$writer->writeElement("class",$parent);
		$this->writeParent($writer, $parent);
		$writer->endElement();
	}

	public function run() {
		$shortname = $this->getArg("code");
		$fullname = $this->getArg("name");
		if($this->getArg("ommit")) {
			$this->_includeMode = self::INCLUDE_OMMIT;
		}
		if($this->getArg("full")) {
			$this->_includeMode = self::INCLUDE_FAST;
		}
		if($shortname && $fullname) {
			$this->export($shortname, $fullname);
			return;
		}
		echo $this->usageHelp();
	}

	protected function merge(SimpleXMLElement $mergeTo, SimpleXMLElement $mergeSource) {
		foreach($mergeSource->children() as $child) {
			/* @var $child SimpleXMLElement */
			$name = $child->getName();
			$xpath = "./".$name;
			if(count($child->attributes())>0) {
				$xpath .= "[";
				$attr = array();
				foreach($child->attributes() as $key => $value) {
					$attr[] = "@".$key."='".$value."'";
				}
				$xpath .= implode(" and ", $attr);
				$xpath .= "]";
			}
			$xpath_result = $mergeTo->xpath($xpath);
			if(count($xpath_result) == 0) {
				$new = $mergeTo->addChild($name, (string)$child);
				foreach($child->attributes() as $key => $value) {
					$new->addAttribute($key, $value);
				}
				$this->merge($new, $child);
			} else {
				if(count($xpath_result)>1) {
					for($i = 1; $i < count($xpath_result); ++$i) {
						$this->merge($xpath_result[0], $xpath_result[$i]);
						unset($xpath_result[$i][0]);
					}
				}
				$this->merge($xpath_result[0], $child);
			}
		}
	}

	protected function scanForFrontendLayouts() {
		$layout = simplexml_load_string("<layout />");
		foreach(glob("../app/design/frontend/*/*/layout/*.xml") as $filename) {
			$this->merge($layout, simplexml_load_file($filename));
		}
		return $layout;
	}

	protected function scanForAdminhtmlLayouts() {
		$layout = simplexml_load_string("<layout />");
		foreach(glob("../app/design/adminhtml/*/*/layout/*.xml") as $filename) {
			$this->merge($layout, simplexml_load_file($filename));
		}
		return $layout;
	}

	protected function getCode($reflection) {
		$filename = $reflection->getFileName();
		$start_line = $reflection->getStartLine()-1;
		$end_line = $reflection->getEndLine();
		$length = $end_line - $start_line;

		$source = file($filename);
		$body = implode("", array_slice($source, $start_line, $length));
		return $body;
	}

	protected function execute($module, $staringPath) {
	//	echo "Fetrching structure of module $module ... ";
		flush();
		$descriptorspec = array(
				0 => array("pipe", "r"),  // stdin is a pipe that the child will read from
				1 => array("pipe", "w"),  // stdout is a pipe that the child will write to
				2 => array("pipe", "w"),  // stderr is a file to write to
		);

		$thisClass = new ReflectionClass("Mage_Shell_EclipsePluginTool");
		$extractStructureMethod = $this->getCode($thisClass->getMethod("exportStructure"));
		$includeAllFunction = $this->getCode($thisClass->getMethod("includeAll"));
		$writeParentFunction = $this->getCode($thisClass->getMethod("writeParent"));
		$shutdownHandlerFunction = $this->getCode(new ReflectionFunction("shutdownHandler"));

		$cwd = '.';
		$env = array();
		$php = isset($_SERVER['_'])?$_SERVER['_']:"php";
		$process = proc_open($php, $descriptorspec, $pipes, $cwd, $env);
		$blackListFile = BLACKLIST_FILE_NAME;
		$contents = <<<CONTENTS
<?php
require_once "abstract.php";

$shutdownHandlerFunction

class Mage_Shell_FileTest extends Mage_Shell_Abstract{

$includeAllFunction
$extractStructureMethod
$writeParentFunction

	public function run() {
		global \$blackList;
		\$blackList = file("$blackListFile", FILE_IGNORE_NEW_LINES);
		\$this->includeAll("$staringPath");
		echo \$this->exportStructure();
	}
}

register_shutdown_function('shutdownHandler');

\$shell = new Mage_Shell_FileTest();
\$shell->run();

CONTENTS;

		if (is_resource($process)) {
			fwrite($pipes[0], $contents);
			fclose($pipes[0]);

			$result = stream_get_contents($pipes[1]);
			fclose($pipes[1]);
			$errors =  stream_get_contents($pipes[2]);
			fclose($pipes[2]);



			$return_value = proc_close($process);

			if ($return_value == 255) {
				if(is_file($result)) {
					$blackList = file(BLACKLIST_FILE_NAME, FILE_IGNORE_NEW_LINES);
					$blackList[] = $result;
					file_put_contents(BLACKLIST_FILE_NAME, implode("\n", $blackList));
					$this->execute($module, $staringPath);
				} else {
					echo "Could not obtain structural data of module $module!\n";
					flush();
				}
			} else {
				global $incrementingStructureData;
				try{
					$resultXml = simplexml_load_string($result);
					if(!$resultXml instanceof SimpleXMLElement) {
						echo "Could not parse structural data of module $module!\n";
					} else if(!$incrementingStructureData instanceof SimpleXMLElement) {
						echo "Structure data corrupted!\n";
					} else {
						$this->merge($incrementingStructureData, $resultXml);
					}
					flush();
				} catch (Exception $e) {
					$msg = $e->getMessage();
					echo "\tStructure data fetch for module $module failed tue to exception: $msg\n";
					flush();
				}
			}
		}
	}

	protected function includeAll($path) {
		$path .= "/";
		if (is_dir($path)) {
			if ($dh = opendir($path)) {
				while (($file = readdir($dh)) !== false) {
					if($file == "." || $file == "..") {
						continue;
					} else if(preg_match("/-.*[0-9].*\.[pP][Hh][pP]$/", $file)) {
						continue; // skipping all install scrpits - only files to have "-" followed by numbers
					} else 	if(is_file($path . $file) && preg_match("/[pP][Hh][pP]$/", $file)) {
						global $includeFilePath, $blackList;
						$includeFilePath = $path . $file;
						if(!in_array($path . $file, $blackList)) {
							ob_start();
							@include_once($path . $file);
							ob_end_clean();
						}
						$includeFilePath = null;
					} else if(is_dir($path . $file)) {
						$this->includeAll($path . $file);
					}
				}
				closedir($dh);
			}
		}
	}

	protected function exportStructure() {
		$writer = new XMLWriter();
		$writer->openMemory();
		$writer->startElement("structure");
		$writer->startElement("classes");
		foreach(get_declared_classes() as $class) {
			if(!preg_match("/^[A-Za-z0-9]+_[A-Za-z0-9]+_[A-Za-z0-9]/", $class))
				continue;
			$writer->startElement($class);
			$reflector = new ReflectionClass($class);
			foreach($reflector->getMethods() as $method) {
				$writer->writeElement("method", $method->name);
			}
			$propetries = $reflector->getDefaultProperties();
			if(isset($propetries['_eventPrefix'])) {
				$writer->writeElement("eventPrefix", $propetries['_eventPrefix']);
			}

			$this->writeParent($writer, $class);
			$writer->endElement();
		}
		$writer->endElement();
		$writer->endElement();
		$struct = $writer->outputMemory();
		return $struct;
	}

	public function export($shortname, $fullname) {
		@ini_set('output_buffering','Off');
		echo "Fetching store config ...\n";
		flush();
		$conifg = Mage::getConfig()->getNode();
		$c = simplexml_load_string($conifg->asXml());
		$adminhtml = Mage::getConfig()->loadModulesConfiguration('adminhtml.xml')->applyExtends();
		$a = simplexml_load_string($adminhtml->getNode()->asXml());
		$this->merge($c->adminhtml, $a);
		$conifg	 = $c;
		echo "Fetching layout updates ...\n";
		flush();
		$frontend_layout = $this->scanForFrontendLayouts();
		$adminhtml_layout = $this->scanForAdminhtmlLayouts();
		echo "Fetching module configurations ...\n";
		flush();
		$system = "<?xml version=\"1.0\" ?><system>\n";
		$adminconfig = Mage::getModel('adminhtml/config');
		$system .= $adminconfig->getSections()->asXml();
		$system .= $adminconfig->getTabs()->asXml();
		$system .= "</system>";
		$system = simplexml_load_string($system);
		switch ($this->_includeMode) {
			case self::INCLUDE_OMMIT:
				echo "Fetching PHP code structure (in include ommit mode: only currently loaded classes will be parsed)\n";
				break;
			case self::INCLUDE_FAST:
				echo "Fetching PHP code structure (may take some time)\n";
				break;
		}
		flush();
		if($this->_includeMode != self::INCLUDE_OMMIT) {
			global $incrementingStructureData;
			$incrementingStructureData = simplexml_load_string("<?xml version=\"1.0\" ?><structure></structure>\n");
			if(!$incrementingStructureData instanceof SimpleXMLElement) {
				echo "DUPA!";
			}
			$c = simplexml_load_string($conifg->asXml());
			$core = $c->xpath("/config/modules/*[codePool='core']");
			foreach($core as $module) {
				$this->execute($module->getName(), "../app/code/core/" . str_replace("_", "/", $module->getName()));
			}
			$community = $c->xpath("/config/modules/*[codePool='community']");
			foreach($community as $module) {
				$this->execute($module->getName(), "../app/code/community/" . str_replace("_", "/", $module->getName()));
			}
			$local = $c->xpath("/config/modules/*[codePool='local']");
			foreach($local as $module) {
				$this->execute($module->getName(), "../app/code/local/" . str_replace("_", "/", $module->getName()));
			}
			$struct = $incrementingStructureData;
		} else {
			$struct = simplexml_load_string($this->exportStructure());
		}
		echo "Removing sensitive data from obtained configuration ...\n";
		flush();
		// database connection data
		$result = $conifg->xpath("//connection[password]");
		foreach($result as $rnode) {
			unset($rnode[0]);
		}
		// store encryption key
		$result = $conifg->xpath("//crypt[key]");
		foreach($result as $rnode) {
			unset($rnode[0]);
		}
		// other modules config
		$keep = array("global", "admin", "modules", "frontend", "adminhtml", "crontab");
		// nodes that are not on $keep list
		$names = array();
		foreach($conifg->children() as $child) {
			$name = $child->getName();
			if(!in_array($name, $keep)) {
				$names[] = $name;
			}
		}
		foreach($names as $name) {
			unset($conifg->$name);
		}
		echo "Creating ZIP archive ...\n";
		flush();
		$path = array(
				".metadata",
				".plugins",
				"pl.mamooth.eclipse.magento",
				"versions",
				$shortname,
		);
		$zip = new ZipArchive();
		if($zip->open($shortname.".zip", ZipArchive::CREATE)) {
			for($i = 1; $i<=count($path); ++$i) {
				$zip->addEmptyDir(implode("/",array_slice($path, 0, $i)));
			}
			array_push($path, "config.xml");
			$zip->addFromString(implode("/", $path), $conifg->asXml());
			array_pop($path);
			array_push($path, "system.xml");
			$zip->addFromString(implode("/", $path), $system->asXml());
			array_pop($path);
			array_push($path, "layout_frontend.xml");
			$zip->addFromString(implode("/", $path), $frontend_layout->asXml());
			array_pop($path);
			array_push($path, "layout_adminhtml.xml");
			$zip->addFromString(implode("/", $path), $adminhtml_layout->asXml());
			array_pop($path);
			array_push($path, "structure.xml");
			$zip->addFromString(implode("/", $path), $struct->asXml());
			array_pop($path);
			array_push($path, "version");
			$zip->addFromString(implode("/", $path), $fullname);
			array_pop($path);
			echo <<<DONE
Archive $shortname.zip created.
Extract this arcive to Your eclipse workspace when creating new project select:
$fullname
as base Magento version to use this shop configuration within Magento Eclipse Plugin.

DONE;
		} else {
			echo "Error ocured while creating ZIP archive.";
		}
	}

	public function usageHelp() {
		$php = isset($_SERVER['_'])?$_SERVER['_']:"php";
		$file = basename($_SERVER['PHP_SELF']);
		return <<<USAGE
Usage:     $php $file [ommit|full] --code ... --name ...

Example:   php $file --code test --name "Test Magento version"

  --code            Internal short name that must be unique and valid direcotry name.
  --name            Full text describing shop version displayed in project creation wizard.
  help              This help
  ommit             Does not try to include attitional file to extend structure information
  full              Includes all possible files when extracting structure information (default)

 This utility creates ZIP archive being base data for Magento Eclipse Plugin context help.
 After archive creation just extract it into Your eclipse workspace.

 Fetching structural data helps provide more helpfull content by Magento Eclipse Plugin.
 Using Full Method for structural data extractions requires PHP CLI to be able to 
 spawn new PHP CLI processes.
 Using Ommit method is fail-safe but it provide minimal help for Magento Eclipse Plugin.

 Output ZIP archive will be created in this directory named after code attribute You specified.

USAGE;
	}
}

$shell = new Mage_Shell_EclipsePluginTool();
$shell->run();
